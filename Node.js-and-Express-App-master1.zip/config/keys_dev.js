module.exports = {
  mongoURI: 'mongodb+srv://melchizedek:kingofsalem@bibleacademy-lbizz.mongodb.net/test?retryWrites=true&w=majority',
  secretOrKey: 'SECRET'
};